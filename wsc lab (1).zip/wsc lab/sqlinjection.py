import sqlite3
def sqli_lab():
    conn = sqlite3.connect(':memory:')
    c = conn.cursor()
    c.execute("CREATE TABLE users (user TEXT, pass TEXT, secret TEXT)")
    c.execute("INSERT INTO users VALUES ('admin', 'SuperComplex_99', 'Root Access Codes')")
    u = input("Username: ")
    p = input("Password: ")   
    query = f"SELECT * FROM users WHERE user = '{u}' AND pass = '{p}'"
    print(f"\nExecuting: {query}")   
    try:
        c.execute(query)
        res = c.fetchone()
        if res:
            print(f"Success! Welcome {res[0]}. Secret Vault: {res[2]}")
        else:
            print("Failed. Incorrect credentials.")
    except Exception as e:
        print(f"Error: {e}")
        
    conn.close()
sqli_lab()