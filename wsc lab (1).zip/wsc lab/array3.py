def test_errors():
    # A simple array for the lab test
    my_array = [10, 0, 50, 25]
    print(f"Current array: {my_array}")
    try:
        # Taking input directly from the user
        index = int(input("Enter the index you want to access: "))
        # Issue 1: The index might not exist (triggers IndexError)
        value = my_array[index]
        # Issue 2: The value might be zero (triggers ZeroDivisionError)
        result = 100 / value
        print(f"Success! 100 / {value} = {result}")
    except IndexError:
        print("Error: Index out of bounds! That slot doesn't exist.") 
    except ZeroDivisionError:
        print("Error: The number at that index is 0. Cannot divide by zero!")   
    except ValueError:
        print("Error: You typed a letter or symbol. Please enter a valid number!")
# Run the program
test_errors()