from http.server import HTTPServer, BaseHTTPRequestHandler
class CookieLab(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        cookie = self.headers.get('Cookie')
        if not cookie:
            self.send_header('Set-Cookie', 'user=LabStudent')
        self.send_header('Content-type', 'text/html')
        self.end_headers()
       if cookie:
            self.wfile.write(f"<h1>Welcome back! Cookie: {cookie}</h1>".encode())
        else:
            self.wfile.write(b"<h1>New User! I set a cookie. Refresh the page!</h1>")
HTTPServer(('127.0.0.1', 8080), CookieLab).serve_forever()