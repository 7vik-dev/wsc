import sys
print(f"Total arguments passed: {len(sys.argv)}")
for index, argument in enumerate(sys.argv):
    print(f"Argument [{index}]: {argument}")