import os
# 1. Create a file with some secret data
open("data.txt", "w").write("Lab Data: Safe and Secure.")
# 2. Lock it down! (0o444 means READ-ONLY, no write/delete)
os.chmod("data.txt", 0o444)
# 3. Prove we can still read it
print("Reading File:", open("data.txt", "r").read())
# 4. Try to write to it (This will instantly crash the program!)
open("data.txt", "w").write("Trying to hack the file...")