import socket
c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
c.connect(('127.0.0.1', 8080))
pwd = input("Password: ")
cmd = input("Command: ")
c.send(f"{pwd}:{cmd}".encode())
print(f"Server replied: {c.recv(1024).decode()}")
c.close()