from http.server import HTTPServer, BaseHTTPRequestHandler
class Server(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"HTTP Test Passed!")
HTTPServer(('127.0.0.1', 8080), Server).serve_forever()