def check_domain_access():
    # The whitelist of trusted domains
    allowed_domains = ["mywebsite.com", "localhost", "127.0.0.1"]    
    print("--- API Server Running ---")   
    # Simulate an incoming request by asking the user for their domain
    request_origin = input("Enter the domain you are connecting from: ").strip()   
    # Check if the domain is in our trusted list
    if request_origin in allowed_domains:
        print(f"[+] Access Granted! {request_origin} is a trusted domain.")
        print("[+] Sending secure data: { 'secret': 'lab_passed' }")
    else:
        print(f"[-] CORS Error: Access Denied!")
        print(f"[-] {request_origin} is not allowed to access this API.")
# Run the program
check_domain_access()