from http.server import HTTPServer, BaseHTTPRequestHandler
class SecureHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)       
        # --- THE 4 ESSENTIAL SECURITY HEADERS ---
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains')
        self.send_header('Content-Security-Policy', "default-src 'self'")        
        # Send standard content type and close headers
        self.send_header('Content-type', 'text/html')
        self.end_headers()  
        # Send a simple webpage back
        self.wfile.write(b"<h1>Secure Server Running!</h1><p>All security headers applied.</p>")
print("Starting secure server on port 8080...")
HTTPServer(('127.0.0.1', 8080), SecureHandler).serve_forever()