import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('127.0.0.1', 8080))
s.listen(1)
print("Secure Server listening on 8080...")
while True:
    conn, addr = s.accept()
    data = conn.recv(1024).decode()   
    if data.startswith("PASS_123:"):
        cmd = data.split(":", 1)[1]
        print(f"Admin {addr} ran: {cmd}")
        conn.send(b"Access Granted!")
    else:
        print(f"Blocked attack from {addr}")
        conn.send(b"Access Denied!") 
    conn.close()