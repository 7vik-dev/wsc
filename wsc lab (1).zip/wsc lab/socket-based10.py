import socket
def test_socket_connection():
    target_ip = input("Enter target IP: ").strip()
    target_port = int(input("Enter target port: "))
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(3)
    try:
        if s.connect_ex((target_ip, target_port)) == 0:
            print(f"Success! Port {target_port} is OPEN.")
        else:
            print(f"Failed. Port {target_port} is CLOSED.")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        s.close()
test_socket_connection()