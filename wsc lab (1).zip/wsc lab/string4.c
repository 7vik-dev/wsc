#include<string.h>
#include<stdio.h>
int main()
{
    char str[100];
    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);
    str[strcspn(str, "\n")] = '\0';
    printf("You entered: %s\n", str);
    return 0;
}