import os
import subprocess
def test_input_vulnerability():
    print("--- Lab Echo Utility ---")   
    # 1. Take input from the user
    user_text = input("Enter text to echo back (Try typing: Hello & whoami): ")   
    print("\n--- VULNERABLE EXECUTION ---")
    # VULNERABLE: Directly mixing input into a shell command
    vulnerable_cmd = f"echo {user_text}"
    print(f"[!] Running exact command: {vulnerable_cmd}")  
    # This will execute any injected commands!
    os.system(vulnerable_cmd)    
    print("\n--- SECURE EXECUTION ---")
    # SECURE: Passing the command and the input as a separated list.
    # The OS now knows that user_text is strictly data, not an executable command.
    print("[+] Running securely...")
    try:
        subprocess.run(["echo", user_text], check=True)
    except Exception as e:
        print(f"[-] Execution failed: {e}")
# Run the lab script
test_input_vulnerability()