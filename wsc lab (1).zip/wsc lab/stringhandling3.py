def safe_string_handler():
    # 1. Take input from the user
    user_input = input("Enter text: ")   
    # 2. Safe check: Strip spaces and see if anything is actually left
    clean_string = user_input.strip()   
    if not clean_string:
        print("Error: Invalid input! You entered an empty string or just spaces.")
    else:
        # 3. Safe to process
        print(f"Success! You entered a valid string: '{clean_string}'")
# Run the program
safe_string_handler()