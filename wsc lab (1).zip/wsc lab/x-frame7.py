from http.server import HTTPServer, BaseHTTPRequestHandler

class SecureHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        
        # THE EXAM REQUIREMENT: The security header
        self.send_header('X-Frame-Options', 'DENY') 
        
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b"<h1>Secure: Framing is Blocked!</h1>")

print("Server running on port 8080 with X-Frame-Options: DENY")
HTTPServer(('127.0.0.1', 8080), SecureHandler).serve_forever()