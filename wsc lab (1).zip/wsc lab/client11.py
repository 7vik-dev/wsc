import urllib.request
try:
    res = urllib.request.urlopen("http://127.0.0.1:8080")
    print(f"Status Code: {res.status}")
    print(f"Server Data: {res.read().decode()}")
except Exception as e:
    print(f"Test Failed: {e}")