import html, urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
class SecureLab(BaseHTTPRequestHandler):
    def do_GET(self):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        safe_input = html.escape(q.get('name', ['Guest'])[0])
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(f"<h1>Welcome, {safe_input}!</h1>".encode())
HTTPServer(('127.0.0.1', 8080), SecureLab).serve_forever()